package com.example.itservicescompany;

import android.app.Activity;
import android.os.Bundle;

public class ContactActivity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		//class to display the contact details
		super.onCreate(savedInstanceState);
		setContentView(R.layout.contactactivity);
	}
}
